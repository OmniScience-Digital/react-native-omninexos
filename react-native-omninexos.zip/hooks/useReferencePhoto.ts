// hooks/useReferencePhoto.ts
import { client } from "@/src/amplify";
import AsyncStorage from "@react-native-async-storage/async-storage";
import NetInfo from "@react-native-community/netinfo";
import { getUrl, list, uploadData } from "aws-amplify/storage";
import * as ImagePicker from "expo-image-picker";
import { useCallback, useEffect, useRef, useState } from "react";
import { AppState, type AppStateStatus } from "react-native";

const SETUP_KEY = (uid: string) => `face:setup_complete:${uid}`;
const PHOTO_URI_KEY = (uid: string) => `face:cached_photo_uri:${uid}`;
// Changes whenever the profile photo changes. Used as the image cache key so
// the picture is read from disk instead of re-downloaded on every launch
// (signed S3 URLs change every time, so the URL itself can't be the key).
const PHOTO_VER_KEY = (uid: string) => `face:photo_version:${uid}`;
const S3_PATH = (uid: string) => `hr/reference-faces/${uid}/profile.jpg`;

// GraphQL for PhotoChangeRequest
const CREATE_PHOTO_REQUEST = /* GraphQL */ `
  mutation CreatePhotoChangeRequest($input: CreatePhotoChangeRequestInput!) {
    createPhotoChangeRequest(input: $input) {
      id
      userId
      status
      createdAt
    }
  }
`;

// Query using the photoRequestsByUserAndDate GSI — hits the index directly,
// no table scan, always returns only this user's records sorted newest first.
const REQUESTS_BY_USER = /* GraphQL */ `
  query PhotoRequestsByUserAndDate($userId: String!) {
    photoRequestsByUserAndDate(
      userId: $userId
      sortDirection: DESC
      limit: 10
    ) {
      items {
        id
        userId
        status
        createdAt
        updatedAt
      }
    }
  }
`;

const UPDATE_PHOTO_REQUEST = /* GraphQL */ `
  mutation UpdatePhotoChangeRequest($input: UpdatePhotoChangeRequestInput!) {
    updatePhotoChangeRequest(input: $input) {
      id
      status
    }
  }
`;

export interface PhotoChangeRequest {
  id: string;
  userId: string;
  status: "PENDING" | "APPROVED" | "DENIED";
  createdAt: string;
  updatedAt?: string;
}

export function useReferencePhoto(userId: string) {
  const [isSetupComplete, setIsSetupComplete] = useState<boolean | null>(null);
  const [photoUri, setPhotoUri] = useState<string | null>(null);
  const [photoVersion, setPhotoVersion] = useState<string>("0");
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pendingRequest, setPendingRequest] =
    useState<PhotoChangeRequest | null>(null);
  const [approvedRequest, setApprovedRequest] =
    useState<PhotoChangeRequest | null>(null);
  const [requestLoading, setRequestLoading] = useState(false);

  // ── Show the cached photo instantly on launch (before any network call) ──
  useEffect(() => {
    if (!userId || userId === "anonymous" || !userId.includes("@")) return;
    let cancelled = false;
    (async () => {
      try {
        const [cached, ver] = await Promise.all([
          AsyncStorage.getItem(PHOTO_URI_KEY(userId)),
          AsyncStorage.getItem(PHOTO_VER_KEY(userId)),
        ]);
        if (cancelled) return;
        if (ver) setPhotoVersion(ver);
        if (cached && cached.startsWith("http")) {
          setPhotoUri((current) => current ?? cached);
        }
      } catch {
        // ignore - the network path below will still load the photo
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [userId]);

  // ── Check setup status on mount ─────────────────────────────────────────
  useEffect(() => {
    if (!userId || userId === "anonymous") return;

    // Guard: userId must be an email. During Cognito auth the user object
    // can briefly carry only `sub` (UUID) before fetchUserAttributes
    // resolves — we wait for the real email before doing anything.
    if (!userId.includes("@")) return;

    const check = async () => {
      const localFlag = await AsyncStorage.getItem(SETUP_KEY(userId));

      // Check connectivity first so we know whether an S3 failure means
      // "no photo" or just "no internet".
      const net = await NetInfo.fetch();
      const online =
        net.isConnected === true && net.isInternetReachable === true;

      if (!online) {
        // Offline — trust the local flag. The S3 verification will run
        // the next time the app starts with a connection.
        setIsSetupComplete(localFlag === "true");
        return;
      }

      // Online — use list() to confirm the file actually exists in S3.
      // getUrl() only generates a signed URL and SUCCEEDS even when the
      // file has been deleted, so we'd get a white broken image and a
      // failed face-verification. list() returns an empty array if absent.
      try {
        const result = await list({ path: S3_PATH(userId) });
        const exists = (result.items ?? []).length > 0;

        if (exists) {
          // File confirmed in S3 — refresh the signed URL and mark complete.
          const { url } = await getUrl({ path: S3_PATH(userId) });
          const freshUrl = url.toString();
          setPhotoUri(freshUrl);
          AsyncStorage.setItem(PHOTO_URI_KEY(userId), freshUrl).catch(() => {});
          const lm = result.items?.[0]?.lastModified;
          if (lm) {
            const ver = String(new Date(lm).getTime());
            setPhotoVersion(ver);
            AsyncStorage.setItem(PHOTO_VER_KEY(userId), ver).catch(() => {});
          }
          if (localFlag !== "true") {
            await AsyncStorage.setItem(SETUP_KEY(userId), "true");
          }
          setIsSetupComplete(true);
        } else {
          // File gone from S3 (admin deleted it) — clear ALL local cache
          // and send the user back to FaceSetup.
          await AsyncStorage.removeItem(SETUP_KEY(userId));
          await AsyncStorage.removeItem(PHOTO_URI_KEY(userId));
          setPhotoUri(null);
          setIsSetupComplete(false);
        }
      } catch (e) {
        console.warn("[photo] could not verify profile photo in storage:", e);
        // Network error during list — fall back to local flag so a brief
        // connectivity blip doesn't force a re-setup.
        setIsSetupComplete(localFlag === "true");
      }
    };

    check();
  }, [userId]);

  // ── Load existing photo from S3 (with offline cache fallback) ──────────
  // Extracted as a standalone callback so any screen using this hook can
  // call reloadPhoto() (e.g. on focus) to pick up a photo that was changed
  // from a DIFFERENT screen — each useReferencePhoto() call has its own
  // local photoUri state, they don't share it automatically.
  const reloadPhoto = useCallback(async () => {
    if (!userId) return;

    // 1. Show cached URI immediately (works offline, like Facebook)
    try {
      const cached = await AsyncStorage.getItem(PHOTO_URI_KEY(userId));
      if (cached && cached.startsWith("http")) setPhotoUri(cached);
    } catch {
      // ignore
    }

    // 2. Try to refresh a fresh signed URL from S3 (online only)
    try {
      const { url } = await getUrl({ path: S3_PATH(userId) });
      const fresh = url.toString();
      setPhotoUri(fresh);
      AsyncStorage.setItem(PHOTO_URI_KEY(userId), fresh).catch(() => {});
    } catch (e) {
      console.warn("[photo] could not get a fresh photo URL:", e);
      // Network unavailable — cached URI already set above, nothing to do.
    }
  }, [userId]);

  useEffect(() => {
    if (!isSetupComplete || !userId) return;
    reloadPhoto();
  }, [isSetupComplete, userId, reloadPhoto]);

  // ── Check for pending/approved requests from DynamoDB ───────────────────
  // Uses the photoRequestsByStatus GSI (same as admin panel) then filters
  // client-side by userId. This avoids the broken listPhotoChangeRequests
  // full-table-scan-with-limit:1 pattern that almost always returns empty.
  const checkRequests = useCallback(async () => {
    if (!userId || userId === "anonymous") return;
    try {
      // Single query scoped to this user — guaranteed to find their record
      // no matter how many other users have requests in the table.
      const { data, errors } = (await client.graphql({
        query: REQUESTS_BY_USER,
        variables: { userId },
        authMode: "userPool",
      })) as any;

      if (!errors) {
        const items: any[] = data?.photoRequestsByUserAndDate?.items ?? [];
        // Sort newest first so we always act on the latest request
        items.sort(
          (a, b) =>
            new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
        );
        setPendingRequest(items.find((r) => r.status === "PENDING") ?? null);
        setApprovedRequest(items.find((r) => r.status === "APPROVED") ?? null);
      }
    } catch {
      // Silent — non-critical
    }
  }, [userId]);

  useEffect(() => {
    checkRequests();
  }, [checkRequests]);

  // ── Refresh on app foreground ────────────────────────────────────────────
  // This hook now lives in a single shared context (ReferencePhotoProvider),
  // so this listener exists exactly ONCE for the whole app rather than being
  // duplicated per-screen. Covers the case where an approval push
  // notification was missed (app was killed, not just backgrounded) — when
  // the user reopens the app, we re-verify approval status from DynamoDB.
  const appStateRef = useRef(AppState.currentState);
  useEffect(() => {
    const sub = AppState.addEventListener(
      "change",
      (nextState: AppStateStatus) => {
        const cameToForeground =
          appStateRef.current.match(/inactive|background/) &&
          nextState === "active";
        appStateRef.current = nextState;
        if (cameToForeground) {
          checkRequests();
        }
      },
    );
    return () => sub.remove();
  }, [checkRequests]);

  // ── Request photo change (creates a pending request) ────────────────────
  const requestPhotoChange = useCallback(async (): Promise<boolean> => {
    if (!userId || userId === "anonymous") return false;
    setRequestLoading(true);
    try {
      const { data, errors } = (await client.graphql({
        query: CREATE_PHOTO_REQUEST,
        variables: {
          input: {
            userId,
            status: "PENDING",
            requestedAt: new Date().toISOString(),
          },
        },
        authMode: "userPool",
      })) as any;
      if (errors) throw new Error(errors[0].message);
      setPendingRequest(data.createPhotoChangeRequest);
      return true;
    } catch (e: any) {
      setError(e?.message ?? "Failed to submit request");
      return false;
    } finally {
      setRequestLoading(false);
    }
  }, [userId]);

  // ── Open camera and capture selfie (only if approved or no photo yet) ───
  const captureAndUpload = useCallback(async (): Promise<boolean> => {
    setError(null);

    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== "granted") {
      setError("Camera permission is required to set up face verification.");
      return false;
    }

    const result = await ImagePicker.launchCameraAsync({
      cameraType: ImagePicker.CameraType.front,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
    });

    if (result.canceled || !result.assets?.[0]?.uri) {
      return false;
    }

    const localUri = result.assets[0].uri;
    setPhotoUri(localUri);
    const newVersion = String(Date.now());
    setPhotoVersion(newVersion);
    AsyncStorage.setItem(PHOTO_VER_KEY(userId), newVersion).catch(() => {});
    // Show the new photo straight away, but do NOT save this path for later:
    // it points into the camera's temporary cache, which the OS clears, so it
    // would show once and then be blank on the next launch. The durable copy
    // is saved below once the upload has succeeded.
    setUploading(true);

    try {
      const response = await fetch(localUri);
      const blob = await response.blob();

      await uploadData({
        path: S3_PATH(userId),
        data: blob,
        options: { contentType: "image/jpeg" },
      }).result;

      await AsyncStorage.setItem(SETUP_KEY(userId), "true");
      setIsSetupComplete(true);

      // If there was an approved request, mark it COMPLETED in DynamoDB
      // and ALWAYS clear it from local state — even if the mutation fails.
      // Keeping it in state would leave the change-photo button permanently
      // unlocked after a successful upload.
      if (approvedRequest) {
        const requestId = approvedRequest.id;
        setApprovedRequest(null); // clear immediately, don't wait for network
        client.graphql({
          query: UPDATE_PHOTO_REQUEST,
          variables: {
            input: { id: requestId, status: "COMPLETED" },
          },
          authMode: "userPool",
        });
      }

      const { url } = await getUrl({ path: S3_PATH(userId) });
      const freshUrl = url.toString();
      setPhotoUri(freshUrl);
      // Update cache with the S3-signed URL so subsequent online loads are fast
      AsyncStorage.setItem(PHOTO_URI_KEY(userId), freshUrl).catch(() => {});
      return true;
    } catch (e: any) {
      setError(e?.message ?? "Upload failed. Please try again.");
      setPhotoUri(null);
      return false;
    } finally {
      setUploading(false);
    }
  }, [userId, approvedRequest]);

  // ── Reset — only available if approved or no photo ───────────────────────
  const resetSetup = useCallback(async () => {
    if (!approvedRequest && isSetupComplete) return; // blocked
    await AsyncStorage.removeItem(SETUP_KEY(userId));
    await AsyncStorage.removeItem(PHOTO_URI_KEY(userId));
    setIsSetupComplete(false);
    setPhotoUri(null);
  }, [userId, approvedRequest, isSetupComplete]);

  const clearError = useCallback(() => setError(null), []);

  // canChangePhoto = no photo set yet OR has an APPROVED request
  const canChangePhoto = !isSetupComplete || !!approvedRequest;

  return {
    isSetupComplete,
    photoUri,
    photoVersion,
    uploading,
    error,
    clearError,
    captureAndUpload,
    resetSetup,
    requestPhotoChange,
    checkRequests,
    reloadPhoto,
    canChangePhoto,
    pendingRequest,
    approvedRequest,
    requestLoading,
    s3Path: S3_PATH(userId),
  };
}
